mypackage

This library is Python package that contain a function that returns the top number (top_n) of items in an array, in descending order.

Building this package locally
python setup.py sdist

Installing this package from Github
pip install git+https://github.com/bmqhamane/mypackage.git

Updating this package from Github
pip install --upgrade git+https://github.com/bmqhamane/mypackage.git

License
MIT